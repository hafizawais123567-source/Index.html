// ✏️ EDIT PRODUCTS HERE. One object per product.
//  id        – unique, no spaces          price     – current price (number)
//  category  – one of CATEGORIES below    oldPrice  – optional; shows discount badge automatically
//  image     – optional path/URL (e.g. 'assets/products/cable.jpg'); leave '' for a placeholder picture
export const CATEGORIES = ['Cables', 'Chargers', 'Power Banks', 'Earphones', 'Stands', 'Car Chargers', 'Adapters', 'Accessories'];

export const PRODUCTS = [
  { id: 'cable-typec', name: 'Type-C Fast Charging Cable (1m)', category: 'Cables', price: 350, oldPrice: 500, image: '', desc: 'Durable braided Type-C cable for fast charging and data transfer.' },
  { id: 'cable-lightning', name: 'Lightning Charging Cable (1m)', category: 'Cables', price: 450, oldPrice: 0, image: '', desc: 'Lightning cable for iPhone charging and syncing.' },
  { id: 'cable-micro', name: 'Micro USB Cable (1.5m)', category: 'Cables', price: 250, oldPrice: 300, image: '', desc: 'Long Micro USB cable for older Android phones and accessories.' },
  { id: 'charger-20w', name: '20W Fast Wall Charger', category: 'Chargers', price: 1200, oldPrice: 1500, image: '', desc: 'Compact 20W USB-C charger suited to most modern phones.' },
  { id: 'charger-33w', name: '33W Dual-Port Charger', category: 'Chargers', price: 1800, oldPrice: 0, image: '', desc: 'Charge two devices at once with one compact adapter.' },
  { id: 'powerbank-20k', name: '20000mAh Fast Charging Power Bank (Black & Gold)', category: 'Power Banks', price: 5500, oldPrice: 6500, image: 'frames/001.jpg', desc: 'High-capacity power bank with an LED display showing the exact battery percentage.' },
  { id: 'powerbank-10k', name: '10000mAh Slim Power Bank', category: 'Power Banks', price: 2800, oldPrice: 3200, image: '', desc: 'Slim and pocket-friendly power bank for daily use.' },
  { id: 'handsfree-mic', name: 'Handsfree with Mic', category: 'Earphones', price: 400, oldPrice: 0, image: '', desc: 'Wired handsfree with clear microphone and call button.' },
  { id: 'earbuds-bt', name: 'Bluetooth Earbuds', category: 'Earphones', price: 2200, oldPrice: 2800, image: '', desc: 'Wireless earbuds with charging case and easy pairing.' },
  { id: 'stand-adjustable', name: 'Adjustable Mobile Stand', category: 'Stands', price: 650, oldPrice: 0, image: '', desc: 'Foldable desk stand for videos, calls and reading.' },
  { id: 'holder-car', name: 'Car Mobile Holder', category: 'Stands', price: 800, oldPrice: 1000, image: '', desc: 'Sturdy dashboard / vent holder with a secure grip.' },
  { id: 'car-dual', name: 'Dual USB Car Charger', category: 'Car Chargers', price: 900, oldPrice: 1100, image: '', desc: 'Two-port car charger to power phones on the road.' },
  { id: 'otg-typec', name: 'OTG Adapter (Type-C)', category: 'Adapters', price: 300, oldPrice: 0, image: '', desc: 'Connect USB flash drives and accessories to your phone.' },
  { id: 'audio-typec', name: 'Type-C to 3.5mm Audio Adapter', category: 'Adapters', price: 450, oldPrice: 0, image: '', desc: 'Use wired earphones on phones without a headphone jack.' },
  { id: 'ring-holder', name: 'Phone Ring Holder', category: 'Accessories', price: 150, oldPrice: 200, image: '', desc: 'Stick-on 360° ring for a secure grip and a handy stand.' },
  { id: 'clean-kit', name: 'Screen Cleaning Kit', category: 'Accessories', price: 200, oldPrice: 0, image: '', desc: 'Spray and microfibre cloth to keep screens spotless.' }
];
