// ✏️ Shop settings – edit these to change name, phone, address, currency.
export const SHOP = {
  brand: 'Dzone PKP',
  shop: 'Lasani Mobile',
  phone: '+923227554728',
  whatsapp: '923227554728',          // digits only, with country code
  address: 'Pakpattan, College Road, near HBL Bank',
  currency: 'Rs.',
  frameCount: 150                      // frames in /frames used by the power bank animation
};
