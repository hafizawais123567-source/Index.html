import { SHOP } from './config.js';
import { money } from './utils.js';
export const waLink = text => `https://wa.me/${SHOP.whatsapp}${text ? '?text=' + encodeURIComponent(text) : ''}`;
export function orderMessage(c, lines, total) {
  const items = lines.map(({ p, qty }, i) => `${i + 1}. ${p.name}\n    ${qty} x ${money(p.price)} = ${money(p.price * qty)}`).join('\n');
  return [`*New Order - ${SHOP.brand}*`, `(${SHOP.shop})`, '', `*Customer:* ${c.name}`, `*Phone:* ${c.phone}`, `*Address:* ${c.address}`, '',
    '*Order Items*', items, '', `*Total: ${money(total)}*`, `*Notes:* ${c.notes || 'None'}`].join('\n');
}
