import { PRODUCTS } from './data/products.js';
const KEY = 'dzone_pkp_cart_v1';
let items = loadCart();
const subs = new Set();
function loadCart() { try { const v = JSON.parse(localStorage.getItem(KEY)); return Array.isArray(v) ? v : []; } catch { return []; } }
function saveCart() { try { localStorage.setItem(KEY, JSON.stringify(items)); } catch {} subs.forEach(f => f()); }
export const cart = {
  qty: id => items.find(i => i.id === id)?.qty || 0,
  add(id, n = 1) { const i = items.find(x => x.id === id); if (i) i.qty = Math.min(99, i.qty + n); else items.push({ id, qty: n }); saveCart(); },
  set(id, q) { if (q <= 0) items = items.filter(x => x.id !== id); else { const i = items.find(x => x.id === id); if (i) i.qty = Math.min(99, q); } saveCart(); },
  remove(id) { items = items.filter(x => x.id !== id); saveCart(); },
  clear() { items = []; saveCart(); },
  lines() { return items.map(i => ({ p: PRODUCTS.find(p => p.id === i.id), qty: i.qty })).filter(l => l.p); },
  count() { return this.lines().reduce((s, l) => s + l.qty, 0); },
  total() { return this.lines().reduce((s, l) => s + l.p.price * l.qty, 0); },
  subscribe(fn) { subs.add(fn); fn(); }
};
