import { PRODUCTS, CATEGORIES } from '../data/products.js';
import { cart } from '../store.js';
import { $, $$, money, discount, imageOf, esc } from '../utils.js';
const state = { q: '', cat: 'All' };
let detailId = null;

const priceHtml = p => `<div class="price"><b>${money(p.price)}</b>${discount(p) ? `<s>${money(p.oldPrice)}</s>` : ''}</div>`;
const badgeHtml = p => (discount(p) ? `<span class="badge">-${discount(p)}% OFF</span>` : '');
function actionsHtml(p, withView) {
  const q = cart.qty(p.id);
  const main = q
    ? `<div class="stepper"><button data-dec aria-label="Decrease">−</button><span>${q}</span><button data-inc aria-label="Increase">+</button></div>`
    : `<button class="btn primary" data-add="${p.id}">Add to Cart</button>`;
  return main + (withView ? `<button class="btn ghost" data-view>Details</button>` : '');
}
function cardHtml(p) {
  return `<article class="card reveal" data-id="${p.id}">
    <button class="thumb" data-view aria-label="View ${esc(p.name)}"><img src="${imageOf(p)}" alt="${esc(p.name)}" loading="lazy">${badgeHtml(p)}</button>
    <div class="info"><small>${p.category}</small><h3>${esc(p.name)}</h3>${priceHtml(p)}<div class="actions">${actionsHtml(p, true)}</div></div></article>`;
}
function matches(p) {
  const q = state.q.trim().toLowerCase();
  const okCat = state.cat === 'All' || (state.cat === 'Offers' ? discount(p) > 0 : p.category === state.cat);
  return okCat && (!q || `${p.name} ${p.category} ${p.desc}`.toLowerCase().includes(q));
}
function renderGrid() {
  const list = PRODUCTS.filter(matches);
  $('#grid').innerHTML = list.map(cardHtml).join('');
  $('#empty').hidden = list.length > 0;
  $('#resultCount').textContent = `${list.length} product${list.length === 1 ? '' : 's'}`;
  $$('#grid .reveal').forEach((el, i) => setTimeout(() => el.classList.add('in'), 40 * Math.min(i, 10)));
}
function renderChips() {
  $('#chips').innerHTML = ['All', 'Offers', ...CATEGORIES].map(c => `<button class="chip${c === state.cat ? ' active' : ''}" data-cat="${c}">${c === 'Offers' ? '🔥 Offers' : c}</button>`).join('');
}
export function showCategory(cat) { state.cat = cat; renderChips(); renderGrid(); }
function renderDetail() {
  const p = PRODUCTS.find(x => x.id === detailId); if (!p) return;
  $('#detailBody').innerHTML = `<div data-id="${p.id}"><div class="d-img"><img src="${imageOf(p)}" alt="${esc(p.name)}">${badgeHtml(p)}</div>
    <small>${p.category}</small><h2>${esc(p.name)}</h2>${priceHtml(p)}<p class="d-desc">${esc(p.desc)}</p><div class="actions">${actionsHtml(p, false)}</div></div>`;
}
export function initProducts() {
  renderChips(); renderGrid();
  $('#search').addEventListener('input', e => { state.q = e.target.value; renderGrid(); });
  $('#searchForm').addEventListener('submit', e => { e.preventDefault(); $('#products').scrollIntoView({ behavior: 'smooth' }); });
  $('#chips').addEventListener('click', e => { const b = e.target.closest('[data-cat]'); if (b) showCategory(b.dataset.cat); });
  $('#clearSearch').addEventListener('click', () => { $('#search').value = ''; state.q = ''; showCategory('All'); });
  $('#grid').addEventListener('click', e => {
    if (!e.target.closest('[data-view]')) return;
    detailId = e.target.closest('[data-id]').dataset.id; renderDetail(); $('#detail').showModal();
  });
  $('#closeDetail').addEventListener('click', () => $('#detail').close());
  $('#detail').addEventListener('click', e => { if (e.target.id === 'detail') e.target.close(); });
  cart.subscribe(() => {
    $$('#grid .card').forEach(card => { const p = PRODUCTS.find(x => x.id === card.dataset.id); card.querySelector('.actions').innerHTML = actionsHtml(p, true); });
    if ($('#detail').open) renderDetail();
  });
}
