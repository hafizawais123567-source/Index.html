import { SHOP } from '../config.js';
import { cart } from '../store.js';
import { $, money, imageOf, esc } from '../utils.js';
import { orderMessage, waLink } from '../whatsapp.js';

let view = 'cart', waUrl = '', clearArmed = false;
const isOpen = () => $('#drawer').classList.contains('open');
export function openCart(v = 'cart') {
  view = v; clearArmed = false; render();
  $('#drawer').classList.add('open'); $('#backdrop').classList.add('show'); document.body.classList.add('lock');
  $('#drawer').setAttribute('aria-hidden', 'false');
}
export function closeCart() {
  $('#drawer').classList.remove('open'); $('#backdrop').classList.remove('show'); document.body.classList.remove('lock');
  $('#drawer').setAttribute('aria-hidden', 'true');
}
const lineHtml = ({ p, qty }) => `<li class="line" data-id="${p.id}">
  <img src="${imageOf(p)}" alt="">
  <div class="l-info"><h4>${esc(p.name)}</h4><span>${money(p.price)} each</span>
    <div class="l-row"><div class="stepper sm"><button data-dec aria-label="Decrease">−</button><span>${qty}</span><button data-inc aria-label="Increase">+</button></div><b>${money(p.price * qty)}</b></div></div>
  <button class="x" data-remove aria-label="Remove">✕</button></li>`;
const totalsHtml = t => `<div class="totals"><div><span>Subtotal</span><b>${money(t)}</b></div><div class="grand"><span>Total</span><b>${money(t)}</b></div></div>`;

function render() {
  const lines = cart.lines(), total = cart.total(), body = $('#drawerBody');
  $('#drawerTitle').textContent = { cart: 'Your Cart', order: 'Place Order', done: 'Order ready' }[view];
  if (view === 'cart') {
    body.innerHTML = lines.length
      ? `<ul class="lines">${lines.map(lineHtml).join('')}</ul>${totalsHtml(total)}
         <div class="cart-actions"><button class="btn ghost" id="clearCart">${clearArmed ? 'Tap again to clear' : 'Clear cart'}</button><button class="btn primary" id="toOrder">Place Order</button></div>`
      : `<div class="empty-cart"><p>🛒</p><p>Your cart is empty.</p><button class="btn primary" id="shopMore">Browse products</button></div>`;
  } else if (view === 'order') {
    body.innerHTML = `<button class="link-btn" id="backCart">← Back to cart</button>
      <form id="orderForm" novalidate>
        <label>Your name<input name="name" autocomplete="name" required placeholder="e.g. Ali Khan"></label>
        <label>Phone number<input name="phone" type="tel" autocomplete="tel" required placeholder="03xx xxxxxxx"></label>
        <label>Delivery address<textarea name="address" rows="2" autocomplete="street-address" required placeholder="House, street, area, city"></textarea></label>
        <label>Notes (optional)<textarea name="notes" rows="2" placeholder="Anything we should know?"></textarea></label>
        <h4 class="sum-title">Order summary</h4>
        <ul class="sum">${lines.map(({ p, qty }) => `<li><span>${esc(p.name)} × ${qty}</span><b>${money(p.price * qty)}</b></li>`).join('')}</ul>
        ${totalsHtml(total)}
        <p class="note">Delivery charges (if any) and payment method will be confirmed with you on WhatsApp.</p>
        <p class="err" id="formErr" role="alert"></p>
        <button class="btn wa-btn" type="submit">Confirm Order on WhatsApp</button>
      </form>`;
  } else {
    body.innerHTML = `<div class="empty-cart"><p>✅</p><p><b>Your order message is ready.</b><br>WhatsApp should open now. Press <b>Send</b> there to confirm your order with ${esc(SHOP.shop)}.</p>
      <a class="btn wa-btn" href="${waUrl}" target="_blank" rel="noopener">Open WhatsApp again</a>
      <button class="btn ghost" id="doneClear">Clear cart &amp; continue shopping</button></div>`;
  }
}
function submitOrder(form) {
  const c = Object.fromEntries(new FormData(form).entries());
  Object.keys(c).forEach(k => (c[k] = String(c[k]).trim()));
  const err = $('#formErr');
  if (c.name.length < 2) return (err.textContent = 'Please enter your name.');
  if (c.phone.replace(/\D/g, '').length < 10) return (err.textContent = 'Please enter a valid phone number.');
  if (c.address.length < 8) return (err.textContent = 'Please enter your full delivery address.');
  waUrl = waLink(orderMessage(c, cart.lines(), cart.total()));
  view = 'done'; render();
  window.open(waUrl, '_blank', 'noopener');
}
export function initCart() {
  $('#cartBtn').addEventListener('click', () => openCart('cart'));
  $('#closeCart').addEventListener('click', closeCart);
  $('#backdrop').addEventListener('click', closeCart);
  addEventListener('keydown', e => e.key === 'Escape' && isOpen() && closeCart());
  $('#drawer').addEventListener('click', e => {
    const id = e.target.id;
    if (id === 'toOrder') { view = 'order'; render(); }
    else if (id === 'backCart') { view = 'cart'; render(); }
    else if (id === 'shopMore') { closeCart(); $('#products').scrollIntoView({ behavior: 'smooth' }); }
    else if (id === 'doneClear') { cart.clear(); view = 'cart'; closeCart(); }
    else if (id === 'clearCart') {
      if (!clearArmed) { clearArmed = true; render(); setTimeout(() => { clearArmed = false; if (isOpen() && view === 'cart') render(); }, 3000); }
      else { clearArmed = false; cart.clear(); }
    }
  });
  $('#drawer').addEventListener('submit', e => { e.preventDefault(); if (e.target.id === 'orderForm') submitOrder(e.target); });
  cart.subscribe(() => { if (isOpen() && view === 'cart') render(); });
}
