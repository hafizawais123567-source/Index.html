import { SHOP } from '../config.js';
import { PRODUCTS } from '../data/products.js';
import { $, money } from '../utils.js';
export function initShowcase() {
  const sec = $('#showcase'), cv = $('#cv'), ctx = cv.getContext('2d');
  const N = SHOP.frameCount;
  const srcs = window.__FRAMES || Array.from({ length: N }, (_, i) => `frames/${String(i + 1).padStart(3, '0')}.jpg`);
  const imgs = [], beats = [...sec.querySelectorAll('.beat')];
  const prod = PRODUCTS.find(p => p.id === 'powerbank-20k');
  if (prod) { $('#scPrice').textContent = money(prod.price); $('#scAdd').dataset.add = prod.id; }
  const stage = $('.stage'), header = $('.top');
  const setHH = () => document.documentElement.style.setProperty('--hh', header.offsetHeight + 'px');
  let W = 0, H = 0, last = -1, cur = 0, target = 0, started = false, loaded = 0;
  const still = matchMedia('(prefers-reduced-motion: reduce)').matches;
  function size() { const d = Math.min(devicePixelRatio || 1, 2); W = cv.clientWidth; H = cv.clientHeight; cv.width = W * d; cv.height = H * d; ctx.setTransform(d, 0, 0, d, 0, 0); last = -1; }
  function draw(i) {
    const im = imgs[i]; if (!im || !im.naturalWidth) return;
    const s = Math.max(W / im.naturalWidth, H / im.naturalHeight) * (W < H ? 0.78 : 1), w = im.naturalWidth * s, h = im.naturalHeight * s;
    ctx.drawImage(im, (W - w) / 2, (H - h) / 2 + (W < H ? H * 0.07 : 0), w, h); last = i;
  }
  function load() {
    if (started) return; started = true;
    srcs.forEach((s, i) => { const im = new Image(); im.onload = () => { loaded++; if (loaded >= N * 0.6) $('#scLoad').hidden = true; if (i === 0) { size(); draw(0); } }; im.src = s; imgs[i] = im; });
  }
  function read() {
    const r = sec.getBoundingClientRect(), total = sec.offsetHeight - stage.offsetHeight, stickyTop = parseFloat(getComputedStyle(stage).top) || 0;
    target = Math.min(1, Math.max(0, (stickyTop - r.top) / total));
    $('#scBar').style.transform = `scaleX(${target})`;
  }
  function fade(p) {
    beats.forEach(b => { const a = +b.dataset.in, z = +b.dataset.out, f = .05;
      const o = Math.max(0, Math.min(1, Math.min((p - a) / f + (a === 0 ? 1 : 0), (z - p) / f)));
      b.style.opacity = o; b.style.transform = `translateY(${(1 - o) * 22}px)`; b.style.pointerEvents = o > .6 ? 'auto' : 'none'; });
  }
  function tick() {
    const r = sec.getBoundingClientRect();
    if (r.bottom > -50 && r.top < innerHeight + 50) {
      cur += (target - cur) * (still ? 1 : .14); if (Math.abs(target - cur) < .0003) cur = target;
      const i = Math.round(cur * (N - 1)); if (i !== last) draw(i); fade(cur);
    }
    requestAnimationFrame(tick);
  }
  new IntersectionObserver((es, o) => { if (es[0].isIntersecting) { load(); o.disconnect(); } }, { rootMargin: '900px' }).observe(sec);
  addEventListener('load', () => setTimeout(load, 1500)); // warm up shortly after the shop has loaded
  addEventListener('scroll', read, { passive: true });
  addEventListener('resize', () => { setHH(); size(); read(); });
  $('#skip').addEventListener('click', e => { e.preventDefault(); $('#products').scrollIntoView({ behavior: 'instant' }); });
  setHH(); size(); read(); cur = target; fade(cur); requestAnimationFrame(tick);
}
