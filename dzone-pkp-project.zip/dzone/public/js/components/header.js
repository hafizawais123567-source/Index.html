import { SHOP } from '../config.js';
import { cart } from '../store.js';
import { $, $$ } from '../utils.js';
import { waLink } from '../whatsapp.js';
export function initHeader() {
  $$('[data-wa]').forEach(a => { a.href = waLink(`Hello ${SHOP.shop}, I have a question.`); a.target = '_blank'; a.rel = 'noopener'; });
  $$('[data-phone]').forEach(el => (el.textContent = SHOP.phone));
  $$('[data-address]').forEach(el => (el.textContent = SHOP.address));
  $$('[data-year]').forEach(el => (el.textContent = new Date().getFullYear()));
  const badge = $('#cartCount');
  cart.subscribe(() => {
    const n = cart.count();
    badge.textContent = n; badge.classList.toggle('on', n > 0);
    badge.classList.remove('pop'); void badge.offsetWidth; badge.classList.add('pop');
  });
}
