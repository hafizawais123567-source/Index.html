import { cart } from './store.js';
import { PRODUCTS } from './data/products.js';
import { $, $$ } from './utils.js';
import { initHeader } from './components/header.js';
import { initProducts, showCategory } from './components/products.js';
import { initCart, openCart } from './components/cart.js';
import { initShowcase } from './components/showcase.js';
import { toast } from './components/toast.js';

initHeader(); initProducts(); initCart(); initShowcase();

// One handler for every Add / + / − / Remove button in the shop (cards, details, cart, showcase).
document.addEventListener('click', e => {
  const btn = e.target.closest('[data-add],[data-inc],[data-dec],[data-remove]'); if (!btn) return;
  const id = btn.dataset.add || btn.closest('[data-id]')?.dataset.id; if (!id) return;
  if ('add' in btn.dataset) { cart.add(id); toast(`✓ Added to cart — ${PRODUCTS.find(p => p.id === id)?.name.split(' (')[0] ?? ''}`); }
  else if ('inc' in btn.dataset) cart.add(id);
  else if ('dec' in btn.dataset) cart.set(id, cart.qty(id) - 1);
  else cart.remove(id);
});
$$('[data-offers]').forEach(a => a.addEventListener('click', () => showCategory('Offers')));
$$('[data-open-cart]').forEach(a => a.addEventListener('click', () => openCart('cart')));

const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12 });
$$('.reveal-s').forEach(el => io.observe(el));
