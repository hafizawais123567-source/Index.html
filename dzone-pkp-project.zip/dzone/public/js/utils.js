import { SHOP } from './config.js';
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const money = n => `${SHOP.currency} ${Math.round(n).toLocaleString('en-US')}`;
export const discount = p => (p.oldPrice && p.oldPrice > p.price ? Math.round((1 - p.price / p.oldPrice) * 100) : 0);
const ICON = { Cables: '🔌', 'Power Banks': '🔋', Chargers: '⚡', Earphones: '🎧', Stands: '📱', 'Car Chargers': '🚗', Adapters: '🔁', Accessories: '🧩' };
const HUE = { Cables: 150, 'Power Banks': 40, Chargers: 200, Earphones: 280, Stands: 170, 'Car Chargers': 10, Adapters: 220, Accessories: 90 };
export function imageOf(p) {
  if (p.image) return p.image;
  const h = HUE[p.category] ?? 150;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${h} 70% 93%)"/><stop offset="1" stop-color="hsl(${h} 60% 78%)"/></linearGradient></defs><rect width="400" height="400" fill="url(#g)"/><text x="200" y="240" font-size="150" text-anchor="middle">${ICON[p.category] || '📦'}</text></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}
export const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
